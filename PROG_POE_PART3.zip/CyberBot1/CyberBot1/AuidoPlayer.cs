﻿using System;
using System.Media;

namespace CyberBot1
{
    public class AudioPlayer
    {
        private readonly string _path;
        public AudioPlayer(string path) => _path = path;

        public void PlayGreeting()
        {
            try
            {
                // Print the path so you can verify where the app is looking
                Console.WriteLine("Looking for audio at: " + System.IO.Path.GetFullPath(_path));

                using var player = new SoundPlayer(_path);
                player.Load();
                player.Play();
            }
            catch (Exception ex)
            {
                Console.ForegroundColor = ConsoleColor.Yellow;
                Console.WriteLine("Audio failed to play: " + ex.Message);
                Console.ResetColor();
            }
        }
    }
}
