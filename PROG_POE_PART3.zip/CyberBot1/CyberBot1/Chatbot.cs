﻿using CyberBot1;
using System;
using System.Threading;

namespace CyberBot1
{
    public class Chatbot1
    {
        private readonly User _user = new User();

        public void Start()
        {
            ConfigureConsoleAppearance();
            ShowHeader();
            AskName();
            TypingEffect($"Hello {_user.Name}! Welcome to the Cybersecurity Bot.");
            MainInteractionLoop();
            Farewell();
            ResetConsoleAppearance();
        }

        private void ConfigureConsoleAppearance()
        { 
            Console.Title = "Cybersecurity Chatbot";
            Console.BackgroundColor = ConsoleColor.Black;
            Console.ForegroundColor = ConsoleColor.Black;
            Console.Clear();
        }

        private void ResetConsoleAppearance()
        {
            Console.ResetColor();
        }

        private void ShowHeader()
        {
            Console.ForegroundColor = ConsoleColor.Black;
            Console.WriteLine("╔════════════════════════════════════════════════════════╗");
            Console.WriteLine("║              CYBERSECURITY AWARENESS CHATBOT           ║");
            Console.WriteLine("╚════════════════════════════════════════════════════════╝");
            Console.ResetColor();

            Console.ForegroundColor = ConsoleColor.DarkGreen;
            Console.WriteLine(@"
  ____ _   _ _   _  ____       ____        _   
 / ___| | | | \ | |/ ___| ___ / ___|  ___ | |_ 
| |   | | | |  \| | |  _ / _ \ |  _  / _ \| __|
| |___| |_| | |\  | |_| |  __/ |_| || (_) | |_ 
 \____|\___/|_| \_|\____|\___|\____(_)___/ \__|
");
            Console.ResetColor();
            Console.WriteLine();
        }

        private void AskName()
        {
            Console.Write("Enter your name: ");
            var name = Console.ReadLine();
            if (string.IsNullOrWhiteSpace(name)) name = "Friend";
            _user.Name = name.Trim();
            Console.WriteLine();
        }

        private void MainInteractionLoop()
        {
            // The session continues until the user types "exit" or "quit"
            while (true)
            {
                ShowMenuPrompt();
                var input = Console.ReadLine();
                if (input == null)
                {
                    Console.WriteLine("Input error. Please try again.");
                    continue;
                }

                var trimmed = input.Trim();
                if (string.IsNullOrWhiteSpace(trimmed))
                {
                    Console.WriteLine("Please enter something.");
                    continue;
                }

                var lower = trimmed.ToLower();

                // Global conversational responses required by the assignment
                if (lower == "how are you" || lower == "how are you?")
                {
                    Console.WriteLine("I'm just code, but I'm here to help you learn about staying safe online.");
                    continue;
                }

                if (lower.Contains("purpose") || lower == "what is your purpose" || lower == "what's your purpose")
                {
                    Console.WriteLine("My purpose is to teach basic cybersecurity awareness and give practical safety tips.");
                    continue;
                }

                // Allow user to exit at any time
                if (lower == "exit" || lower == "quit")
                {
                    break;
                }

                // If user typed "menu" show options again
                if (lower == "menu" || lower == "options")
                {
                    DisplayOptions();
                    continue;
                }

                // If user asked a direct cybersecurity question (keyword matching)
                if (lower.Contains("password") || lower.Contains("phishing") || lower.Contains("2fa") ||
                    lower.Contains("two-factor") || lower.Contains("privacy") || lower.Contains("wifi") ||
                    lower.Contains("social") || lower.Contains("updates") || lower.Contains("patch"))
                {
                    // Route to the appropriate explanation
                    HandleKeywordQuestion(lower);
                    continue;
                }

                // If user entered a number or keyword to choose a menu item
                if (TryHandleMenuChoice(lower))
                {
                    // after handling, loop back to menu
                    continue;
                }

                // Unknown input fallback
                Console.WriteLine("I didn't quite understand that. Type 'menu' to see options or type 'exit' to quit.");
            }
        }

        private void ShowMenuPrompt()
        {
            Console.WriteLine();
            TypingEffect("What would you like to learn about today? (type number or keyword; 'menu' to show options; 'exit' to quit)");
            DisplayOptions();
            Console.Write("> ");
        }

        private void DisplayOptions()
        {
            Console.ForegroundColor = ConsoleColor.DarkMagenta;
            Console.WriteLine("--------------------------------------------------------");
            Console.WriteLine("1. Password best practices");
            Console.WriteLine("2. Phishing and suspicious emails");
            Console.WriteLine("3. Two-factor authentication (2FA)");
            Console.WriteLine("4. Online privacy and data protection");
            Console.WriteLine("5. Safe use of public Wi-Fi");
            Console.WriteLine("6. Social media safety");
            Console.WriteLine("7. Software updates and patching");
            Console.WriteLine("--------------------------------------------------------");
            Console.ResetColor();
        }

        private bool TryHandleMenuChoice(string lower)
        {
            if (lower == "1" || lower.Contains("password"))
            {
                ExplainPasswordSafety();
                return true;
            }
            if (lower == "2" || lower.Contains("phishing"))
            {
                ExplainPhishing();
                return true;
            }
            if (lower == "3" || lower.Contains("2fa") || lower.Contains("two"))
            {
                ExplainTwoFactor();
                return true;
            }
            if (lower == "4" || lower.Contains("privacy"))
            {
                ExplainPrivacy();
                return true;
            }
            if (lower == "5" || lower.Contains("wifi") || lower.Contains("public"))
            {
                ExplainPublicWifi();
                return true;
            }
            if (lower == "6" || lower.Contains("social") || lower.Contains("media"))
            {
                ExplainSocialMedia();
                return true;
            }
            if (lower == "7" || lower.Contains("updates") || lower.Contains("patch"))
            {
                ExplainSoftwareUpdates();
                return true;
            }
            return false;
        }

        private void HandleKeywordQuestion(string lower)
        {
            if (lower.Contains("password"))
            {
                ExplainPasswordSafety();
            }
            else if (lower.Contains("phishing"))
            {
                ExplainPhishing();
            }
            else if (lower.Contains("2fa") || lower.Contains("two-factor") || lower.Contains("two factor"))
            {
                ExplainTwoFactor();
            }
            else if (lower.Contains("privacy"))
            {
                ExplainPrivacy();
            }
            else if (lower.Contains("wifi") || lower.Contains("public"))
            {
                ExplainPublicWifi();
            }
            else if (lower.Contains("social") || lower.Contains("media"))
            {
                ExplainSocialMedia();
            }
            else if (lower.Contains("update") || lower.Contains("patch"))
            {
                ExplainSoftwareUpdates();
            }
            else
            {
                Console.WriteLine("I can help with passwords, phishing, 2FA, privacy, public Wi-Fi, social media, and updates. Type 'menu' to see options.");
            }
        }

        private void ExplainPasswordSafety()
        {
            TypingEffect("Topic: Password best practices");
            Console.WriteLine();
            Console.WriteLine("What it is:");
            Console.WriteLine("A password is a secret string that protects your accounts from unauthorized access.");
            Console.WriteLine();
            Console.WriteLine("How to be careful:");
            Console.WriteLine("- Use long passphrases (12+ characters).");
            Console.WriteLine("- Use unique passwords for each account.");
            Console.WriteLine("- Use a reputable password manager to generate and store passwords.");
            Console.WriteLine("- Enable 2FA where available.");
        }

        private void ExplainPhishing()
        {
            TypingEffect("Topic: Phishing and suspicious emails");
            Console.WriteLine();
            Console.WriteLine("What it is:");
            Console.WriteLine("Phishing is a scam where attackers trick you into revealing credentials or clicking malicious links.");
            Console.WriteLine();
            Console.WriteLine("How to be careful:");
            Console.WriteLine("- Verify the sender's email address carefully.");
            Console.WriteLine("- Do not click links or open attachments from unknown senders.");
            Console.WriteLine("- Hover over links to see the real URL before clicking.");
            Console.WriteLine("- When in doubt, go directly to the official website.");
        }

        private void ExplainTwoFactor()
        {
            TypingEffect("Topic: Two-factor authentication (2FA)");
            Console.WriteLine();
            Console.WriteLine("What it is:");
            Console.WriteLine("2FA adds a second verification step beyond your password, such as a code or biometric.");
            Console.WriteLine();
            Console.WriteLine("How to be careful:");
            Console.WriteLine("- Enable 2FA on all accounts that support it.");
            Console.WriteLine("- Prefer authenticator apps or hardware keys over SMS.");
            Console.WriteLine("- Keep backup codes in a secure place.");
        }

        private void ExplainPrivacy()
        {
            TypingEffect("Topic: Online privacy and data protection");
            Console.WriteLine();
            Console.WriteLine("What it is:");
            Console.WriteLine("Privacy is about controlling who can see and use your personal information online.");
            Console.WriteLine();
            Console.WriteLine("How to be careful:");
            Console.WriteLine("- Review app and website privacy settings regularly.");
            Console.WriteLine("- Limit the personal data you share publicly.");
            Console.WriteLine("- Use strong, unique passwords and 2FA to protect accounts.");
            Console.WriteLine("- Delete accounts you no longer use.");
        }

        private void ExplainPublicWifi()
        {
            TypingEffect("Topic: Safe use of public Wi-Fi");
            Console.WriteLine();
            Console.WriteLine("What it is:");
            Console.WriteLine("Public Wi-Fi networks are shared and can be monitored by others on the same network.");
            Console.WriteLine();
            Console.WriteLine("How to be careful:");
            Console.WriteLine("- Avoid sensitive transactions on public Wi-Fi.");
            Console.WriteLine("- Use a trusted VPN when connecting to public networks.");
            Console.WriteLine("- Prefer mobile data for sensitive tasks when possible.");
            Console.WriteLine("- Ensure websites use HTTPS before entering credentials.");
        }

        private void ExplainSocialMedia()
        {
            TypingEffect("Topic: Social media safety");
            Console.WriteLine();
            Console.WriteLine("What it is:");
            Console.WriteLine("Social media platforms let you share content but can expose personal information to strangers.");
            Console.WriteLine();
            Console.WriteLine("How to be careful:");
            Console.WriteLine("- Review and tighten privacy settings on your accounts.");
            Console.WriteLine("- Think before sharing personal details or location.");
            Console.WriteLine("- Be cautious of friend requests from unknown people.");
            Console.WriteLine("- Use strong passwords and enable 2FA for social accounts.");
        }

        private void ExplainSoftwareUpdates()
        {
            TypingEffect("Topic: Software updates and patching");
            Console.WriteLine();
            Console.WriteLine("What it is:");
            Console.WriteLine("Updates and patches fix security vulnerabilities and improve software stability.");
            Console.WriteLine();
            Console.WriteLine("How to be careful:");
            Console.WriteLine("- Keep your operating system and apps up to date.");
            Console.WriteLine("- Enable automatic updates where practical.");
            Console.WriteLine("- Only install updates from official sources.");
            Console.WriteLine("- Restart devices when updates require it.");
        }

        private void Farewell()
        {
            Console.WriteLine();
            TypingEffect("Nice learning with you — until next time.");
            Console.WriteLine();
        }

        private void TypingEffect(string text, int delay = 18)
        {
            foreach (char c in text)
            {
                Console.Write(c);
                Thread.Sleep(delay);
            }
            Console.WriteLine();
        }
    }
}

