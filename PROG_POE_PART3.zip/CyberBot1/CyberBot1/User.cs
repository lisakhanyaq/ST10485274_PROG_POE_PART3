﻿namespace CyberBot1
{
    public class User
    {
        public string Name { get; set; } = "Friend";
    }
}