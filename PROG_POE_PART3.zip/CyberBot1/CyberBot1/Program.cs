﻿using System;

namespace CyberBot1
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.Title = "Cybersecurity Chatbot";

            // Enable audio greeting
            var audio = new AudioPlayer("greeting.wav");
            audio.PlayGreeting();

            var bot = new Chatbot1();
            bot.Start();
        }
    }
}
