using System;
using System.Collections.Generic;

namespace CybersecurityChatbot
{
    /// <summary>
    /// Manages the cybersecurity quiz mini-game.
    /// Includes 15+ questions covering phishing, passwords, safe browsing, social engineering,
    /// 2FA, malware, privacy, and backup. Shows one question at a time with immediate feedback.
    /// </summary>
    public class QuizManager
    {
        private List<QuizQuestion> _questions;
        private int _currentIndex = 0;
        private int _score = 0;

        public QuizManager()
        {
            InitialiseQuestions();
        }

        private void InitialiseQuestions()
        {
            _questions = new List<QuizQuestion>
            {
                // Phishing - 3 questions
                new QuizQuestion
                {
                    Question = "What should you do if you receive an email asking for your password?",
                    Options = new List<string> { "A) Reply with your password", "B) Delete the email", "C) Report it as phishing", "D) Ignore it" },
                    CorrectAnswer = "C",
                    Explanation = "✓ Correct! Legitimate companies never ask for passwords via email. Reporting it helps prevent scams.",
                    IsTrueFalse = false
                },
                new QuizQuestion
                {
                    Question = "True or False: A misspelled URL like 'paypa1.com' instead of 'paypal.com' is a common phishing tactic.",
                    Options = new List<string> { "True", "False" },
                    CorrectAnswer = "True",
                    Explanation = "✓ Correct! Attackers rely on users not noticing small differences in domain names.",
                    IsTrueFalse = true
                },
                new QuizQuestion
                {
                    Question = "How can you verify a suspicious email before clicking any links?",
                    Options = new List<string> { "A) Hover over the link to see the actual URL", "B) Go to the official website directly", "C) Call the company using a known phone number", "D) All of the above" },
                    CorrectAnswer = "D",
                    Explanation = "✓ Correct! Using all three methods gives you maximum confidence the email is legitimate.",
                    IsTrueFalse = false
                },

                // Password Safety - 3 questions
                new QuizQuestion
                {
                    Question = "What is the minimum recommended password length?",
                    Options = new List<string> { "A) 6 characters", "B) 8 characters", "C) 12+ characters", "D) 20+ characters" },
                    CorrectAnswer = "C",
                    Explanation = "✓ Correct! Passwords of 12+ characters with mixed case, numbers, and symbols are much harder to crack.",
                    IsTrueFalse = false
                },
                new QuizQuestion
                {
                    Question = "True or False: It's okay to use the same password on multiple websites.",
                    Options = new List<string> { "True", "False" },
                    CorrectAnswer = "False",
                    Explanation = "✓ Correct! If one site is breached, attackers can use that password to break into all your accounts.",
                    IsTrueFalse = true
                },
                new QuizQuestion
                {
                    Question = "Which is the BEST way to store your passwords securely?",
                    Options = new List<string> { "A) Write them in a notebook", "B) Use a password manager like Bitwarden", "C) Keep them in your browser", "D) Memorise them all" },
                    CorrectAnswer = "B",
                    Explanation = "✓ Correct! Password managers encrypt and securely store your passwords.",
                    IsTrueFalse = false
                },

                // Safe Browsing / HTTPS - 2 questions
                new QuizQuestion
                {
                    Question = "What does the 'S' in 'HTTPS' stand for?",
                    Options = new List<string> { "A) Secure", "B) Standard", "C) Safe", "D) System" },
                    CorrectAnswer = "A",
                    Explanation = "✓ Correct! HTTPS encrypts data between you and the website, protecting it from being intercepted.",
                    IsTrueFalse = false
                },
                new QuizQuestion
                {
                    Question = "True or False: It's safe to enter your credit card information on a website that only has HTTP (no S).",
                    Options = new List<string> { "True", "False" },
                    CorrectAnswer = "False",
                    Explanation = "✓ Correct! Without HTTPS, your data is sent in plain text and can be intercepted by attackers.",
                    IsTrueFalse = true
                },

                // Two-Factor Authentication - 2 questions
                new QuizQuestion
                {
                    Question = "What is the best form of two-factor authentication (2FA)?",
                    Options = new List<string> { "A) SMS text messages", "B) Email codes", "C) An authenticator app or hardware key", "D) Security questions" },
                    CorrectAnswer = "C",
                    Explanation = "✓ Correct! Authenticator apps and hardware keys cannot be intercepted like SMS can.",
                    IsTrueFalse = false
                },
                new QuizQuestion
                {
                    Question = "True or False: 2FA makes it impossible for attackers to access your account even if they have your password.",
                    Options = new List<string> { "True", "False" },
                    CorrectAnswer = "True",
                    Explanation = "✓ Correct! Even with your password, attackers still need the second factor (code, biometric, etc.).",
                    IsTrueFalse = true
                },

                // Social Engineering - 2 questions
                new QuizQuestion
                {
                    Question = "What is social engineering?",
                    Options = new List<string> { "A) Hacking into networks with code", "B) Manipulating people into giving up sensitive information", "C) Using malware to steal data", "D) Encrypting files for ransom" },
                    CorrectAnswer = "B",
                    Explanation = "✓ Correct! Social engineers are manipulators, not necessarily technical experts.",
                    IsTrueFalse = false
                },
                new QuizQuestion
                {
                    Question = "True or False: Attackers often impersonate IT support or a manager to trick you into giving up credentials.",
                    Options = new List<string> { "True", "False" },
                    CorrectAnswer = "True",
                    Explanation = "✓ Correct! Always verify the identity of anyone requesting sensitive information by calling back on a known number.",
                    IsTrueFalse = true
                },

                // Malware & Ransomware - 2 questions
                new QuizQuestion
                {
                    Question = "What should you do if you think your computer has malware?",
                    Options = new List<string> { "A) Ignore it and hope it goes away", "B) Run antivirus scans immediately", "C) Disconnect from the internet", "D) Both B and C" },
                    CorrectAnswer = "D",
                    Explanation = "✓ Correct! Disconnect first to prevent spread, then run a full antivirus scan.",
                    IsTrueFalse = false
                },
                new QuizQuestion
                {
                    Question = "True or False: You should pay the ransom if ransomware encrypts your files.",
                    Options = new List<string> { "True", "False" },
                    CorrectAnswer = "False",
                    Explanation = "✓ Correct! Paying funds future attacks and does not guarantee your files will be recovered.",
                    IsTrueFalse = true
                },

                // Privacy & Data Protection - 2 questions
                new QuizQuestion
                {
                    Question = "What is the best practice for protecting your privacy online?",
                    Options = new List<string> { "A) Share your full name and birthdate on social media", "B) Review and limit privacy settings on all accounts", "C) Never use the internet", "D) Use public Wi-Fi for banking" },
                    CorrectAnswer = "B",
                    Explanation = "✓ Correct! Regularly review your privacy settings on every app and social media platform.",
                    IsTrueFalse = false
                },
                new QuizQuestion
                {
                    Question = "True or False: If your email appears in a data breach, you should immediately change your password.",
                    Options = new List<string> { "True", "False" },
                    CorrectAnswer = "True",
                    Explanation = "✓ Correct! You can check if your email was breached at haveibeenpwned.com.",
                    IsTrueFalse = true
                },

                // Backup & Disaster Recovery - 1 question
                new QuizQuestion
                {
                    Question = "How often should you back up your important files?",
                    Options = new List<string> { "A) Once a year", "B) Once a month", "C) Weekly or more frequently", "D) Only before holidays" },
                    CorrectAnswer = "C",
                    Explanation = "✓ Correct! Regular backups protect you from ransomware, hardware failure, and accidental deletion.",
                    IsTrueFalse = false
                }
            };

            // Shuffle questions for variety
            ShuffleQuestions();
        }

        private void ShuffleQuestions()
        {
            // Fisher-Yates shuffle for randomness
            var random = new Random();
            for (int i = _questions.Count - 1; i > 0; i--)
            {
                int randomIndex = random.Next(i + 1);
                var temp = _questions[i];
                _questions[i] = _questions[randomIndex];
                _questions[randomIndex] = temp;
            }
        }

        public QuizQuestion GetCurrentQuestion() =>
            _currentIndex < _questions.Count ? _questions[_currentIndex] : null;

        public bool SubmitAnswer(string answer)
        {
            if (_currentIndex >= _questions.Count) return false;

            var question = _questions[_currentIndex];
            var correct = answer.ToUpper() == question.CorrectAnswer.ToUpper();

            if (correct) _score++;
            _currentIndex++;

            return correct;
        }

        public string GetFeedback(bool correct)
        {
            if (_currentIndex > 0 && _currentIndex <= _questions.Count)
            {
                var question = _questions[_currentIndex - 1];
                return question.Explanation;
            }
            return string.Empty;
        }

        public bool IsFinished() => _currentIndex >= _questions.Count;

        public string GetFinalScore() => $"{_score}/{_questions.Count}";

        public string GetFinalMessage()
        {
            var percentage = (_score * 100) / _questions.Count;
            if (percentage >= 90) return "🏆 Excellent! You're a cybersecurity expert!";
            if (percentage >= 80) return "✓ Great job! You know your security fundamentals.";
            if (percentage >= 70) return "Good effort! Keep learning to improve your score.";
            return "Keep studying! Cybersecurity takes practice. Review the topics you struggled with.";
        }

        public void ResetQuiz()
        {
            _currentIndex = 0;
            _score = 0;
            InitialiseQuestions();
        }

        public int GetTotalQuestions() => _questions.Count;
    }
}
