using System.Collections.Generic;

namespace CybersecurityChatbot
{
    /// <summary>
    /// Detects the emotional tone of user input and provides empathetic response openers.
    /// After detecting sentiment, ChatBot will automatically follow up with a relevant tip.
    /// </summary>
    public enum Sentiment { Neutral, Worried, Curious, Frustrated, Happy }

    public class SentimentDetector
    {
        private readonly Dictionary<Sentiment, List<string>> _triggers = new()
        {
            [Sentiment.Worried] = new()
            {
                "worried", "scared", "afraid", "anxious", "nervous",
                "unsafe", "concerned", "fear", "frightened", "panic",
                "at risk", "vulnerable", "threatened", "danger"
            },
            [Sentiment.Curious] = new()
            {
                "curious", "wondering", "interested", "want to know",
                "how does", "what is", "tell me about", "explain",
                "learn", "understand", "how do i", "what are"
            },
            [Sentiment.Frustrated] = new()
            {
                "frustrated", "annoyed", "confused", "don't understand",
                "angry", "difficult", "hard", "can't", "cant",
                "stuck", "lost", "complicated", "useless", "pointless"
            },
            [Sentiment.Happy] = new()
            {
                "great", "thanks", "helpful", "awesome", "love it",
                "amazing", "good", "thank you", "fantastic", "excellent",
                "brilliant", "nice", "cool", "perfect", "appreciate"
            }
        };

        private readonly Dictionary<Sentiment, string> _openers = new()
        {
            [Sentiment.Worried]    = "I understand this can feel overwhelming — you're not alone, and taking steps to learn is exactly the right move. ",
            [Sentiment.Curious]    = "Great question! Curiosity is your best security tool — here's what you need to know: ",
            [Sentiment.Frustrated] = "I hear you — cybersecurity can seem complex at first. Let's break it down simply: ",
            [Sentiment.Happy]      = "Glad to hear that! Let's keep that positive energy going with a quick tip: ",
            [Sentiment.Neutral]    = string.Empty
        };

        public Sentiment Detect(string input)
        {
            var lower = input.ToLower();
            foreach (var kvp in _triggers)
                foreach (var word in kvp.Value)
                    if (lower.Contains(word))
                        return kvp.Key;

            return Sentiment.Neutral;
        }

        public string GetSentimentResponse(Sentiment sentiment) =>
            _openers.TryGetValue(sentiment, out var opener) ? opener : string.Empty;
    }
}
