using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace CybersecurityChatbot
{
    /// <summary>
    /// Records every significant chatbot action with timestamp and description.
    /// Shows last 5-10 entries by default, with a "show more" option for full history.
    /// </summary>
    public class ActivityLogger
    {
        private readonly List<string> _log = new();

        /// <summary>Adds an action to the log with a timestamp.</summary>
        public void Log(string action)
        {
            var timestamp = DateTime.Now.ToString("[HH:mm:ss]");
            var entry = $"{timestamp} {action}";
            _log.Add(entry);
        }

        /// <summary>Gets the last 'count' entries (default 10). Shows "Show More" button if more exist.</summary>
        public string GetRecentLog(int count = 10)
        {
            if (_log.Count == 0)
                return "No activity recorded yet.";

            var recent = _log.TakeLast(count).ToList();
            var sb = new StringBuilder("📋 Recent Activity:\n\n");

            for (int i = 0; i < recent.Count; i++)
                sb.AppendLine($"{i + 1}. {recent[i]}");

            return sb.ToString();
        }

        /// <summary>Gets all log entries (used for "show more" feature).</summary>
        public string GetFullLog()
        {
            if (_log.Count == 0)
                return "No activity recorded yet.";

            var sb = new StringBuilder("📋 Complete Activity History:\n\n");

            for (int i = 0; i < _log.Count; i++)
                sb.AppendLine($"{i + 1}. {_log[i]}");

            return sb.ToString();
        }

        /// <summary>Returns the number of log entries.</summary>
        public int GetCount() => _log.Count;

        /// <summary>Checks if there are more entries than the default display limit.</summary>
        public bool HasMoreEntries(int displayLimit = 10) => _log.Count > displayLimit;

        /// <summary>Clears the log (useful for testing).</summary>
        public void Clear() => _log.Clear();
    }
}
