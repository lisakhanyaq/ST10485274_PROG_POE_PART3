using System.Collections.Generic;

namespace CybersecurityChatbot
{
    /// <summary>
    /// Represents a single quiz question with multiple choice or true/false format.
    /// Used by QuizManager to store and manage questions.
    /// </summary>
    public class QuizQuestion
    {
        public string Question { get; set; }
        public List<string> Options { get; set; }  // For multiple choice: "A", "B", "C", "D" or "True", "False"
        public string CorrectAnswer { get; set; }  // e.g. "A", "C", "True"
        public string Explanation { get; set; }    // Shown after answering
        public bool IsTrueFalse { get; set; }       // True if T/F, false if multiple choice
    }
}
