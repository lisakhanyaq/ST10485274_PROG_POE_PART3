using System;
using System.Media;

namespace CybersecurityChatbot
{
    /// <summary>
    /// Plays the WAV greeting file on application startup.
    /// Reused from Parts 1 & 2 — works in both console and WPF contexts.
    /// 
    /// IMPORTANT: In Visual Studio, right-click greeting.wav in Solution Explorer,
    /// open Properties, and set "Copy to Output Directory" to "Copy always".
    /// </summary>
    public class AudioPlayer
    {
        private readonly string _path;

        public AudioPlayer(string path) => _path = path;

        public void PlayGreeting()
        {
            try
            {
                var fullPath = System.IO.Path.GetFullPath(_path);
                using var player = new SoundPlayer(fullPath);
                player.Load();
                player.Play();
            }
            catch (Exception)
            {
                // Audio failure is non-critical — the app continues normally.
            }
        }
    }
}
