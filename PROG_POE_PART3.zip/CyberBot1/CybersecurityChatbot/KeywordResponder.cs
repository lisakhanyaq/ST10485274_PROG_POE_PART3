using System;
using System.Collections.Generic;

namespace CybersecurityChatbot
{
    /// <summary>
    /// Enhanced KeywordResponder with Part 3 NLP intent phrases.
    /// Includes expanded phrase variations for natural language understanding.
    /// </summary>
    public class KeywordResponder
    {
        private readonly Random _random = new();

        // Cybersecurity keywords and responses (from Part 2, expanded)
        private readonly Dictionary<string, List<string>> _responses = new()
        {
            ["password"] = new()
            {
                "Use a passphrase of 12+ characters mixing uppercase, lowercase, numbers, and symbols. Avoid dictionary words.",
                "Never reuse passwords. A password manager generates and stores unique passwords securely.",
                "Strong passwords are your first line of defence. Pair them with 2FA for maximum protection.",
                "Avoid predictable patterns — randomness is key. A password manager can help generate truly random passwords.",
                "Change your password if you suspect a breach. Check haveibeenpwned.com to see if your email was compromised."
            },
            ["phishing"] = new()
            {
                "Phishing creates false urgency like 'Your account will be closed!' Slow down and verify the sender.",
                "Before clicking links, hover over them to see the real URL. Legitimate companies never ask for passwords via email.",
                "Watch for domain misspellings — 'paypa1.com' instead of 'paypal.com' is a classic phishing trick.",
                "When in doubt, go directly to the official website. Never trust unexpected email links.",
                "Report phishing emails to help prevent others from falling victim to the same scam."
            },
            ["privacy"] = new()
            {
                "Review privacy settings on every app and social media. Limit what personal data you expose publicly.",
                "Think before posting — once it's online, you lose control. Screenshots last forever.",
                "Use a VPN on public networks, clear cookies regularly, and consider privacy-focused browsers like Firefox.",
                "Data brokers collect your info without permission. Services like DeleteMe can help you opt out.",
                "Disable location services on apps that don't need them. Your location data is valuable to advertisers."
            },
            ["malware"] = new()
            {
                "Update antivirus software and run scans regularly. Malware hides inside free downloads.",
                "Never open attachments from unknown senders — PDFs and documents can contain malicious code.",
                "Malware disguises itself as legitimate software. Download only from official sources.",
                "Sudden slowdowns and unexpected pop-ups signal malware. Scan immediately and disconnect if needed.",
                "Backup files to an external drive. If infected, you won't lose your data."
            },
            ["ransomware"] = new()
            {
                "Backup files offline. Ransomware can't encrypt what it can't access.",
                "Ransomware spreads via phishing and downloads. Be cautious of unexpected emails.",
                "Never pay the ransom — no guarantee of recovery, and you fund future attacks.",
                "Network segmentation protects devices. IoT devices should be on a separate network.",
                "Restore from backups after infection. Update all systems to prevent reinfection."
            },
            ["vpn"] = new()
            {
                "A VPN masks your IP and encrypts traffic. Always use one on public Wi-Fi.",
                "Choose reputable VPNs with verified no-logs policies. Free VPNs often sell your data.",
                "A VPN improves privacy but doesn't make you fully anonymous. Combine it with good habits.",
                "Look for a kill switch feature — it blocks traffic if your VPN drops.",
                "Test your VPN connection to ensure it's actually hiding your IP."
            },
            ["2fa"] = new()
            {
                "2FA adds a second verification step beyond your password. Even if stolen, your account is safe.",
                "Authenticator apps are more secure than SMS, which can be intercepted via SIM-swapping.",
                "Save backup codes offline. You could permanently lose access without them.",
                "Enable 2FA on email first — it controls password resets for all other accounts.",
                "Biometric 2FA (fingerprint, face) is convenient and very secure."
            },
            ["scam"] = new()
            {
                "If it sounds too good to be true, it is. Scammers exploit urgency and greed.",
                "Never send money to someone you haven't met. Wire transfers are irreversible.",
                "Check website registration dates and look for physical contact info. Scam sites hide these.",
                "Romance scammers build trust slowly before asking for money. Be suspicious of unexpected requests.",
                "Report scams to the FTC and your bank to help protect others."
            },
            ["firewall"] = new()
            {
                "A firewall monitors network traffic and blocks unauthorized access. Keep it enabled.",
                "Hardware firewalls (in your router) protect all connected devices.",
                "Firewalls alone aren't enough — layer them with antivirus and updates.",
                "Review firewall logs for unusual activity. Repeated blocked attempts can warn of attacks.",
                "Configure firewall rules to only allow necessary connections."
            },
            ["social engineering"] = new()
            {
                "Social engineers manipulate people, not systems. They impersonate IT, CEOs, or friends.",
                "Always verify identity by calling back on a trusted number, not a number they provided.",
                "Tailgating is physical social engineering — secure doors prevent unauthorized access.",
                "Awareness is your strongest defence. Question unexpected requests for sensitive info.",
                "Train yourself and others to recognize manipulation tactics."
            },
            ["update"] = new()
            {
                "Keep your OS and apps updated — patches fix critical security vulnerabilities.",
                "Enable automatic updates where possible. Manual updates are easy to forget.",
                "Only install updates from official sources. Fake update popups are malware delivery.",
                "Restart after updates to complete installation. Some security fixes require reboots.",
                "Check your device's security update status regularly."
            },
            ["backup"] = new()
            {
                "Back up important files regularly to an external drive or cloud storage.",
                "Use the 3-2-1 rule: 3 copies of data, 2 different media, 1 offsite location.",
                "Test your backups to ensure they actually restore. Broken backups won't help in a crisis.",
                "Disconnect external backups after use to protect them from ransomware.",
                "Cloud backups are convenient but check the provider's security practices."
            },
            ["https"] = new()
            {
                "HTTPS encrypts data between you and the website. Always use it for sensitive transactions.",
                "Never enter credit card info on HTTP sites — data is sent in plain text.",
                "Look for the padlock icon in your browser. It means the connection is secure.",
                "Even HTTPS doesn't verify the website is legitimate — check the domain carefully.",
                "Self-signed certificates show a warning — avoid sites with these."
            },
            ["wifi"] = new()
            {
                "Public Wi-Fi networks can be monitored by others. Use a VPN for all traffic.",
                "Don't do banking on public Wi-Fi. Use mobile data for sensitive transactions.",
                "Disable auto-connect and turn off Wi-Fi when you don't need it.",
                "Name your home Wi-Fi something generic — don't reveal router type.",
                "Use WPA3 encryption (or WPA2 as minimum) on your home network."
            }
        };

        public string GetResponse(string input)
        {
            var lower = input.ToLower();
            foreach (var kvp in _responses)
                if (lower.Contains(kvp.Key))
                    return kvp.Value[_random.Next(kvp.Value.Count)];

            return string.Empty;
        }

        public string GetMatchedKeyword(string input)
        {
            var lower = input.ToLower();
            foreach (var key in _responses.Keys)
                if (lower.Contains(key))
                    return key;

            return string.Empty;
        }

        public IEnumerable<string> GetAllKeywords() => _responses.Keys;
    }
}
