using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using Newtonsoft.Json;

namespace CybersecurityChatbot
{
    /// <summary>
    /// Handles all file I/O operations for tasks.json.
    /// All CRUD operations go through this class.
    /// 
    /// Attribution: Newtonsoft.Json - https://www.newtonsoft.com/json
    /// </summary>
    public class TaskStorageHelper
    {
        private const string FilePath = "tasks.json";

        /// <summary>Reads tasks.json and deserialises to a List of CyberTask objects.</summary>
        public List<CyberTask> LoadTasks()
        {
            try
            {
                if (!File.Exists(FilePath))
                    return new List<CyberTask>();

                var json = File.ReadAllText(FilePath);
                return JsonConvert.DeserializeObject<List<CyberTask>>(json) ?? new List<CyberTask>();
            }
            catch (Exception ex)
            {
                System.Diagnostics.Debug.WriteLine($"Error loading tasks: {ex.Message}");
                return new List<CyberTask>();
            }
        }

        /// <summary>Serialises a list of tasks to JSON and writes to tasks.json.</summary>
        public void SaveTasks(List<CyberTask> tasks)
        {
            try
            {
                var json = JsonConvert.SerializeObject(tasks, Formatting.Indented);
                File.WriteAllText(FilePath, json);
            }
            catch (Exception ex)
            {
                System.Diagnostics.Debug.WriteLine($"Error saving tasks: {ex.Message}");
            }
        }

        /// <summary>Adds a new task and saves the file immediately.</summary>
        public void AddTask(string title, string description, string reminder)
        {
            var tasks = LoadTasks();
            
            var newId = tasks.Count > 0 ? tasks.Max(t => t.Id) + 1 : 1;
            var newTask = new CyberTask
            {
                Id = newId,
                Title = title,
                Description = description,
                Reminder = reminder,
                IsComplete = false,
                CreatedAt = DateTime.Now.ToString("yyyy-MM-dd HH:mm")
            };

            tasks.Add(newTask);
            SaveTasks(tasks);
        }

        /// <summary>Marks a task as complete by ID and saves the file.</summary>
        public void MarkAsComplete(int id)
        {
            var tasks = LoadTasks();
            var task = tasks.FirstOrDefault(t => t.Id == id);

            if (task != null)
            {
                task.IsComplete = true;
                SaveTasks(tasks);
            }
        }

        /// <summary>Deletes a task by ID and saves the file.</summary>
        public void DeleteTask(int id)
        {
            var tasks = LoadTasks();
            tasks.RemoveAll(t => t.Id == id);
            SaveTasks(tasks);
        }

        /// <summary>Gets the file path (for debugging or validation).</summary>
        public string GetFilePath() => Path.GetFullPath(FilePath);
    }
}
