using System;

namespace CybersecurityChatbot
{
    /// <summary>
    /// Represents a single cybersecurity task.
    /// Serialised to and from JSON via TaskStorageHelper.
    /// </summary>
    public class CyberTask
    {
        public int Id { get; set; }
        public string Title { get; set; }
        public string Description { get; set; }
        public string Reminder { get; set; }
        public bool IsComplete { get; set; }
        public string CreatedAt { get; set; }
    }
}
