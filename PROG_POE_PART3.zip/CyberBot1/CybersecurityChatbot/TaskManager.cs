using System.Collections.Generic;

namespace CybersecurityChatbot
{
    /// <summary>
    /// Business logic layer for task management.
    /// Calls TaskStorageHelper for persistence and ActivityLogger for logging.
    /// </summary>
    public class TaskManager
    {
        private readonly TaskStorageHelper _storage;
        private readonly ActivityLogger _logger;

        public TaskManager(ActivityLogger logger = null)
        {
            _storage = new TaskStorageHelper();
            _logger = logger;
        }

        /// <summary>Adds a new task and logs the action.</summary>
        public string AddTask(string title, string description, string reminder)
        {
            _storage.AddTask(title, description, reminder);
            _logger?.Log($"Task added: '{title}' (Reminder: {(string.IsNullOrEmpty(reminder) ? "None" : reminder)})");
            return $"✓ Task added: '{title}'. Would you like a reminder?";
        }

        /// <summary>Gets all tasks from storage.</summary>
        public List<CyberTask> GetAllTasks()
        {
            return _storage.LoadTasks();
        }

        /// <summary>Marks a task as complete and logs the action.</summary>
        public string MarkAsComplete(int id)
        {
            var tasks = _storage.LoadTasks();
            var task = tasks.Find(t => t.Id == id);

            if (task != null)
            {
                _storage.MarkAsComplete(id);
                _logger?.Log($"Task marked complete: '{task.Title}'");
                return $"✓ '{task.Title}' marked as complete!";
            }

            return "Task not found.";
        }

        /// <summary>Deletes a task and logs the action.</summary>
        public string DeleteTask(int id)
        {
            var tasks = _storage.LoadTasks();
            var task = tasks.Find(t => t.Id == id);

            if (task != null)
            {
                _storage.DeleteTask(id);
                _logger?.Log($"Task deleted: '{task.Title}'");
                return $"✓ '{task.Title}' deleted.";
            }

            return "Task not found.";
        }

        /// <summary>Gets a task by ID.</summary>
        public CyberTask GetTaskById(int id)
        {
            var tasks = _storage.LoadTasks();
            return tasks.Find(t => t.Id == id);
        }

        /// <summary>Updates a task's reminder and logs it.</summary>
        public string SetReminder(int id, string reminder)
        {
            var tasks = _storage.LoadTasks();
            var task = tasks.Find(t => t.Id == id);

            if (task != null)
            {
                task.Reminder = reminder;
                _storage.SaveTasks(tasks);
                _logger?.Log($"Reminder set for '{task.Title}': {reminder}");
                return $"✓ Reminder set: '{reminder}'";
            }

            return "Task not found.";
        }
    }
}
