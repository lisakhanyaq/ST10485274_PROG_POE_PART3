using System.Collections.Generic;

namespace CybersecurityChatbot
{
    /// <summary>
    /// Stores and recalls user-specific information across the conversation session.
    /// Handles name, favourite topic, and arbitrary key-value memory.
    /// </summary>
    public class MemoryStore
    {
        public string UserName { get; set; } = string.Empty;
        public string FavouriteTopic { get; set; } = string.Empty;

        private readonly Dictionary<string, string> _store = new();

        /// <summary>Saves any key-value pair to memory.</summary>
        public void Store(string key, string value) =>
            _store[key.ToLower()] = value;

        /// <summary>Retrieves a previously stored value by key.</summary>
        public string Recall(string key) =>
            _store.TryGetValue(key.ToLower(), out var val) ? val : string.Empty;

        /// <summary>
        /// Builds a personalised opener sentence using stored info.
        /// Used to prefix bot responses with context-aware greetings.
        /// </summary>
        public string GetPersonalisedOpener()
        {
            if (!string.IsNullOrEmpty(UserName) && !string.IsNullOrEmpty(FavouriteTopic))
                return $"As someone interested in {FavouriteTopic}, {UserName}, here's what you should know: ";

            if (!string.IsNullOrEmpty(UserName))
                return $"{UserName}, ";

            return string.Empty;
        }

        public bool HasName => !string.IsNullOrEmpty(UserName);
        public bool HasFavouriteTopic => !string.IsNullOrEmpty(FavouriteTopic);
    }
}
