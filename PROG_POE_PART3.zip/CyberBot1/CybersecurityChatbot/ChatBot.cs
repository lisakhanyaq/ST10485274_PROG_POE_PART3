using System;
using System.Collections.Generic;

namespace CybersecurityChatbot
{
    /// <summary>
    /// Enhanced chatbot with NLP intent detection for Part 3 features.
    /// Routes user input through task, quiz, log intents before falling back to Part 2 logic.
    /// </summary>
    public class ChatBot
    {
        private readonly KeywordResponder _keywords   = new();
        private readonly SentimentDetector _sentiment = new();
        private readonly MemoryStore _memory          = new();
        private readonly ActivityLogger _logger       = new();
        private readonly TaskManager _tasks;
        private readonly QuizManager _quiz;
        private readonly Random _random             = new();

        private bool _awaitingName = true;
        private bool _inQuiz = false;
        private string _lastTopic = string.Empty;
        private int _pendingTaskId = -1;

        private readonly List<string> _fallbackResponses = new()
        {
            "I didn't quite understand that. Try: 'add a task', 'start quiz', 'show activity log', or ask about passwords, phishing, 2FA, etc.",
            "Hmm, I'm not sure. You can ask me about cybersecurity topics, add tasks, take a quiz, or view your activity log.",
            "I didn't catch that. Type 'help' or 'menu' to see what I can do.",
            "That's outside my knowledge. Try asking about a cybersecurity topic or using one of my features!"
        };

        private readonly List<string> _generalTips = new()
        {
            "Start with the basics: use strong unique passwords and enable 2FA on every important account.",
            "Keep all your software and operating system updated — most attacks exploit known, patchable vulnerabilities.",
            "Check if your email has appeared in a data breach at haveibeenpwned.com.",
            "Security starts with awareness. The more you know about threats, the safer you become."
        };

        public ChatBot()
        {
            _tasks = new TaskManager(_logger);
            _quiz = new QuizManager();
        }

        public string GetGreeting() =>
            "🔐 Welcome to the Cybersecurity Awareness Bot!\n\nWhat's your name?";

        public string ProcessInput(string input)
        {
            if (string.IsNullOrWhiteSpace(input))
                return "Please type something — I'm here to help!";

            var trimmed = input.Trim();
            var lower   = trimmed.ToLower();

            // ── Step 1: Name capture ──────────────────────────────────────
            if (_awaitingName)
            {
                _memory.UserName = trimmed;
                _awaitingName    = false;
                _logger.Log($"User logged in as '{_memory.UserName}'");

                var keywords = string.Join(", ", _keywords.GetAllKeywords());
                return $"Great to meet you, {_memory.UserName}! 👋\n\n" +
                       $"I can help with cybersecurity topics, manage tasks, run a quiz, and log activities.\n\n" +
                       $"Topics: {keywords}\n\n" +
                       $"Try: 'add a task', 'start quiz', 'show activity log', or ask about any topic!";
            }

            // ── Step 2: In-quiz handling ──────────────────────────────────
            if (_inQuiz)
                return HandleQuizFlow(trimmed, lower);

            // ── Step 3: Task intent detection ──────────────────────────────
            if (lower.Contains("add task") || lower.Contains("add a task") || 
                lower.Contains("create task") || lower.Contains("enable ") ||
                lower.Contains("set up "))
            {
                return HandleTaskIntent(trimmed, lower);
            }

            // ── Step 4: Reminder intent ───────────────────────────────────
            if (lower.Contains("remind me") && _pendingTaskId >= 0)
            {
                return HandleReminderIntent(trimmed, lower);
            }

            // ── Step 5: Quiz intent ───────────────────────────────────────
            if (lower.Contains("start quiz") || lower.Contains("take quiz") ||
                lower.Contains("test my knowledge") || lower.Contains("quiz me") ||
                lower.Contains("play the game") || lower == "quiz")
            {
                return LaunchQuiz();
            }

            // ── Step 6: Activity log intent ────────────────────────────────
            if (lower.Contains("show activity log") || lower.Contains("what have you done") ||
                lower.Contains("what did you do") || lower.Contains("show log") ||
                lower.Contains("recent actions") || lower == "log")
            {
                _logger.Log("User viewed activity log");
                return DisplayActivityLog();
            }

            // ── Step 7: Special commands ──────────────────────────────────
            if (lower is "help" or "menu" or "topics" or "what can you do")
            {
                var response = "Here's what I can do:\n\n" +
                               "🔐 Cybersecurity Topics: " + string.Join(", ", _keywords.GetAllKeywords()) + "\n" +
                               "📋 Tasks: 'add a task to [do something]'\n" +
                               "🎮 Quiz: 'start quiz'\n" +
                               "📊 Activity Log: 'show activity log'\n\n" +
                               "Just ask about a topic or use one of the commands above!";
                return response;
            }

            if (lower is "how are you" or "how are you?")
                return "I'm running at full security — all systems operational! How can I help you stay safe today?";

            if (lower.Contains("purpose") || lower.Contains("who are you"))
                return $"I'm your personal cybersecurity guide, {_memory.UserName}! I help you learn security tips, manage tasks, take quizzes, and track our interactions.";

            if (lower is "exit" or "quit" or "bye" or "goodbye")
            {
                _logger.Log($"User {_memory.UserName} logged out");
                return $"Stay safe online, {_memory.UserName}! Remember: strong passwords, 2FA enabled, and stay sceptical. Goodbye! 👋";
            }

            // ── Step 8: Follow-up handling ────────────────────────────────
            if (lower.Contains("tell me more") || lower.Contains("more info") ||
                lower.Contains("explain more") || lower == "more")
            {
                if (!string.IsNullOrEmpty(_lastTopic))
                {
                    var followUp = _keywords.GetResponse(_lastTopic);
                    _logger.Log($"Follow-up requested for topic: {_lastTopic}");
                    return $"Here's another tip on {_lastTopic}:\n\n{followUp}\n\n" +
                           $"💡 Type 'tell me more' for yet another angle on this topic.";
                }
                return "What topic would you like to explore? Ask about passwords, phishing, VPNs, or try 'help' to see options.";
            }

            // ── Step 9: Sentiment + keyword (Part 2 flow) ──────────────────
            var detectedSentiment = _sentiment.Detect(lower);
            var sentimentOpener   = _sentiment.GetSentimentResponse(detectedSentiment);
            var keyword = _keywords.GetMatchedKeyword(lower);

            if (!string.IsNullOrEmpty(keyword))
            {
                _lastTopic = keyword;

                if (detectedSentiment == Sentiment.Curious || lower.Contains("interested in"))
                    _memory.FavouriteTopic = keyword;

                var keywordResponse = _keywords.GetResponse(lower);
                _logger.Log($"Keyword matched: {keyword}");

                var bridge = (_memory.HasFavouriteTopic && _memory.FavouriteTopic != keyword)
                    ? $"As someone interested in {_memory.FavouriteTopic}, you'll also want to know: "
                    : string.Empty;

                return $"{sentimentOpener}{bridge}{keywordResponse}\n\n💡 Type 'tell me more' for another tip on {keyword}.";
            }

            // ── Step 10: Sentiment-only fallback ──────────────────────────
            if (detectedSentiment != Sentiment.Neutral)
            {
                var autoTip = _generalTips[_random.Next(_generalTips.Count)];
                return $"{sentimentOpener}{autoTip}";
            }

            // ── Step 11: Random fallback ──────────────────────────────────
            return _fallbackResponses[_random.Next(_fallbackResponses.Count)];
        }

        private string HandleTaskIntent(string trimmed, string lower)
        {
            // Extract task name from various phrasings
            var taskName = ExtractTaskName(trimmed, lower);

            if (string.IsNullOrEmpty(taskName))
                return "What task would you like to add? For example: 'add task - Enable two-factor authentication'";

            // Add task with empty description for now
            _tasks.AddTask(taskName, $"Complete: {taskName}", "");

            var allTasks = _tasks.GetAllTasks();
            _pendingTaskId = allTasks[allTasks.Count - 1].Id;

            return $"✓ Task added: '{taskName}'\n\nWould you like a reminder? (Say 'yes' or 'remind me in X days')";
        }

        private string HandleReminderIntent(string trimmed, string lower)
        {
            if (lower.Contains("no") || lower == "skip" || lower == "nope")
            {
                _pendingTaskId = -1;
                return "✓ Task saved without reminder.";
            }

            // Extract reminder text
            var reminder = ExtractReminder(trimmed);
            _tasks.SetReminder(_pendingTaskId, reminder);
            _pendingTaskId = -1;

            return $"✓ Reminder set: {reminder}";
        }

        private string LaunchQuiz()
        {
            _inQuiz = true;
            _quiz.ResetQuiz();
            _logger.Log("Quiz started");
            return DisplayQuizQuestion();
        }

        private string HandleQuizFlow(string trimmed, string lower)
        {
            if (lower is "quit" or "exit" or "stop" or "end")
            {
                _inQuiz = false;
                var score = _quiz.GetFinalScore();
                _logger.Log($"Quiz ended - Final score: {score}");
                return $"You've exited the quiz. Final score was {score}. Come back anytime!";
            }

            // Submit answer
            var answer = trimmed.ToUpper();
            var correct = _quiz.SubmitAnswer(answer);
            var feedback = _quiz.GetFeedback(correct);

            if (_quiz.IsFinished())
            {
                _inQuiz = false;
                var finalScore = _quiz.GetFinalScore();
                var finalMsg = _quiz.GetFinalMessage();
                _logger.Log($"Quiz completed - Score: {finalScore}");

                return $"{feedback}\n\n🎯 Quiz Complete!\n" +
                       $"Final Score: {finalScore}\n\n{finalMsg}\n\n" +
                       $"Type 'start quiz' to play again, or ask about any cybersecurity topic!";
            }

            return $"{feedback}\n\n{DisplayQuizQuestion()}";
        }

        private string DisplayQuizQuestion()
        {
            var q = _quiz.GetCurrentQuestion();
            if (q == null) return "Quiz complete!";

            var sb = new System.Text.StringBuilder();
            sb.AppendLine($"Question {_quiz.GetCurrentQuestion() != null}: {q.Question}\n");

            if (q.IsTrueFalse)
            {
                sb.AppendLine("A) True");
                sb.AppendLine("B) False");
            }
            else
            {
                for (int i = 0; i < q.Options.Count; i++)
                    sb.AppendLine(q.Options[i]);
            }

            sb.AppendLine($"\n(Answer with: A, B, C, D, or True/False)");
            return sb.ToString();
        }

        private string DisplayActivityLog()
        {
            var recentLog = _logger.GetRecentLog(10);
            var hasMore = _logger.HasMoreEntries(10);

            if (hasMore)
                return recentLog + "\n\nType 'show more' to see the complete history.";

            return recentLog;
        }

        private string ExtractTaskName(string trimmed, string lower)
        {
            // Remove common task intent phrases
            var taskName = lower
                .Replace("add task", "")
                .Replace("add a task", "")
                .Replace("create task", "")
                .Replace("enable ", "")
                .Replace("set up ", "")
                .Replace("-", "")
                .Trim();

            return taskName.Length > 0 ? char.ToUpper(taskName[0]) + taskName.Substring(1) : "";
        }

        private string ExtractReminder(string trimmed)
        {
            // Extract reminder phrase
            var lower = trimmed.ToLower();
            if (lower.Contains("remind me in")) return trimmed.Substring(trimmed.IndexOf("remind me in", StringComparison.OrdinalIgnoreCase));
            if (lower.Contains("remind me ")) return trimmed.Substring(trimmed.IndexOf("remind me ", StringComparison.OrdinalIgnoreCase));
            return "Reminder set";
        }

        public ActivityLogger GetActivityLogger() => _logger;
        public TaskManager GetTaskManager() => _tasks;
        public QuizManager GetQuizManager() => _quiz;
    }
}
