using System;
using System.Windows;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;

namespace CybersecurityChatbot
{
    public partial class MainWindow : Window
    {
        private ChatBot _chatBot;
        private TaskManager _taskManager;
        private AudioPlayer _audioPlayer;

        public MainWindow()
        {
            InitializeComponent();
            _chatBot = new ChatBot();
            _taskManager = _chatBot.GetTaskManager();
            _audioPlayer = new AudioPlayer("greeting.wav");

            _audioPlayer.PlayGreeting();
            LoadAsciiArt();
            AppendBotMessage(_chatBot.GetGreeting());
            RefreshTaskList();
            UserInputBox.Focus();
        }

        private void SendButton_Click(object sender, RoutedEventArgs e) => SendMessage();

        private void UserInput_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.Key == Key.Enter)
                SendMessage();
        }

        private void SendMessage()
        {
            var input = UserInputBox.Text.Trim();
            if (string.IsNullOrWhiteSpace(input)) return;

            AppendUserMessage(input);
            UserInputBox.Clear();

            var response = _chatBot.ProcessInput(input);
            AppendBotMessage(response);

            RefreshTaskList();
            ChatDisplay.ScrollToEnd();
            StatusLabel.Text = $"Message sent at {DateTime.Now:HH:mm:ss}";
            UserInputBox.Focus();
        }

        private void AddTaskButton_Click(object sender, RoutedEventArgs e)
        {
            var title = TaskTitleBox.Text.Trim();
            var reminder = ReminderBox.Text.Trim();

            if (string.IsNullOrEmpty(title))
            {
                AppendBotMessage("Please enter a task title.");
                return;
            }

            _taskManager.AddTask(title, $"Complete: {title}", reminder);
            AppendBotMessage($"✓ Task added: '{title}'{(string.IsNullOrEmpty(reminder) ? "" : $"\n  Reminder: {reminder}")}");

            TaskTitleBox.Clear();
            ReminderBox.Clear();
            RefreshTaskList();
        }

        private void CompleteTask_Click(object sender, RoutedEventArgs e)
        {
            var selected = TaskListBox.SelectedItem as string;
            if (selected == null)
            {
                AppendBotMessage("Please select a task to mark as complete.");
                return;
            }

            var taskId = int.Parse(selected.Split('.')[0].Trim());
            var response = _taskManager.MarkAsComplete(taskId);
            AppendBotMessage(response);
            RefreshTaskList();
        }

        private void DeleteTask_Click(object sender, RoutedEventArgs e)
        {
            var selected = TaskListBox.SelectedItem as string;
            if (selected == null)
            {
                AppendBotMessage("Please select a task to delete.");
                return;
            }

            var taskId = int.Parse(selected.Split('.')[0].Trim());
            var response = _taskManager.DeleteTask(taskId);
            AppendBotMessage(response);
            RefreshTaskList();
        }

        private void RefreshTaskList()
        {
            TaskListBox.Items.Clear();
            var tasks = _taskManager.GetAllTasks();

            foreach (var task in tasks)
            {
                var status = task.IsComplete ? "✓" : "○";
                var reminder = string.IsNullOrEmpty(task.Reminder) ? "" : $" ({task.Reminder})";
                TaskListBox.Items.Add($"{task.Id}. {status} {task.Title}{reminder}");
            }
        }

        private void AppendUserMessage(string message)
        {
            var para = new Paragraph { Margin = new Thickness(0, 4, 0, 0) };
            para.Inlines.Add(new Run("You: ")
            {
                Foreground = new SolidColorBrush(Color.FromRgb(0xAD, 0xFF, 0x2F)),
                FontWeight = System.Windows.FontWeights.Bold
            });
            para.Inlines.Add(new Run(message)
            {
                Foreground = new SolidColorBrush(Color.FromRgb(0xE0, 0xE0, 0xE0))
            });
            ChatDisplay.Document.Blocks.Add(para);
        }

        private void AppendBotMessage(string message)
        {
            var separator = new Paragraph { Margin = new Thickness(0) };
            separator.Inlines.Add(new Run("────────────────────────────────────")
            {
                Foreground = new SolidColorBrush(Color.FromRgb(0x22, 0x33, 0x44)),
                FontSize = 8
            });
            ChatDisplay.Document.Blocks.Add(separator);

            var para = new Paragraph { Margin = new Thickness(0, 2, 0, 4) };
            para.Inlines.Add(new Run("Bot: ")
            {
                Foreground = new SolidColorBrush(Color.FromRgb(0x00, 0xBF, 0xFF)),
                FontWeight = System.Windows.FontWeights.Bold
            });
            para.Inlines.Add(new Run(message)
            {
                Foreground = new SolidColorBrush(Color.FromRgb(0xCC, 0xEE, 0xFF))
            });
            ChatDisplay.Document.Blocks.Add(para);
            ChatDisplay.ScrollToEnd();
        }

        private void LoadAsciiArt()
        {
            AsciiArtDisplay.Text =
@"  ____ _   _ ____  _____ ____     ____   ___ _____ 
 / ___| | | | __ )| ____|  _ \   | __ ) / _ \_   _|
| |   | | | |  _ \|  _| | |_) |  |  _ \| | | || |  
| |___| |_| | |_) | |___| _ <   | |_) | |_| || |  
 \____|\___/|____/|_____|_| \_\  |____/ \___/ |_|";
        }
    }
}